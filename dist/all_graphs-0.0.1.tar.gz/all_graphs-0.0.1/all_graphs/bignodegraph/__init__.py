from graphs.graph import Graph
from graphs.weightedgraphs import WeightedGraph