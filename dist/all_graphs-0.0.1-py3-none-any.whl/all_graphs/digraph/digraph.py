from graphs import Graph

class Digraph(Graph):
    def __init__(self, ad_matrix):
        super.__init__(ad_matrix)

    def isconnected(self):
        pass